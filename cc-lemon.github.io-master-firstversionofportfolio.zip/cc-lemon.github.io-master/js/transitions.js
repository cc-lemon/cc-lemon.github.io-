var button = document.getElementById('hype-button');


button.addEventListener('click', function(event){
  button.classList.toggle('button-popped')
});